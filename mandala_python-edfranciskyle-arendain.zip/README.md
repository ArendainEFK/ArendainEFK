# Hello! Hola! Bonjour! Salve!

### About The Design

🟠 While designing my Mandala Art I was mostly inspired by
    the more traditional designs where shapes and patterns
    are being repeated with little changes.<br />

🟠 In my design I mostly used the turtle circle command while
    designing the flower, and also the division between the,
    patterns, also made use of functions, as well as the
    extent attribute of the circle command. However, I couldn't
    really fit the whole mandala art because I didn't know how.<br />
    
🟠 I did not use any color because again I wanted to stick
    with the traditional aesthetic of the mandala art which
    is mostly monochromatic, or black and white.<br />

### Reference Used

🟠 Youtube
🟠 Class Videos/Notes
🟠 W3Schools :D